public class YouTubeDataParserException extends Exception {
    public YouTubeDataParserException(String message) {
        super(message);
    }
}
